








define(temp_r, w9)

fmt1: .string "a is %d and b is %d\n"

a_size = 4                                  // Size of variable 'a'
b_size = 4                                  // Size of variable 'b'
alloc = -(16 + a_size + b_size) & -16       // Allocate stack space, aligned to 16 bytes
dealloc = -alloc                            // Deallocate stack space

a_s = 16                                    // Offset for variable 'a' in stack
b_s = 20                                    // Offset for variable 'b' in stack

.balign 4                                   // Align the code section on a 4-byte boundary
.global main                                // Declare the "main" function as a global symbol

main:
    stp x29, x30, [sp, alloc]!              // Save FP (x29) and LR (x30) and allocate stack space
    mov x29, sp                             // Set FP to the current SP

    mov w19, 5                              // Initialize 'a' to 5
    str w19, [x29, a_s]                     // Store 'a' in the stack

    mov w20, 7                              // Initialize 'b' to 7
    str w20, [x29, b_s]                     // Store 'b' in the stack

    adrp x0, fmt1                           // Load the address of 'fmt1' (high part)
    add x0, x0, :lo12:fmt1                  // Add the lower 12-bit offset of 'fmt1'
    ldr w1, [x29, a_s]                      // Load 'a' into register w1
    ldr w2, [x29, b_s]                      // Load 'b' into register w2
    bl printf                               // Call printf to print "a is %d and b is %d"

    add x0, x29, a_s                        // Set up the address of 'a' as the first argument
    add x1, x29, b_s                        // Set up the address of 'b' as the second argument
    bl swap                                 // Call the swap function

    adrp x0, fmt1                           // Load the address of 'fmt1' (high part)
    add x0, x0, :lo12:fmt1                  // Add the lower 12-bit offset of 'fmt1'
    ldr w1, [x29, a_s]                      // Load 'a' after swap
    ldr w2, [x29, b_s]                      // Load 'b' after swap
    bl printf                               // Call printf to print swapped values

    mov w0, 0                               // Set return value to 0
    ldp x29, x30, [sp], dealloc             // Restore FP and LR, deallocate stack
    ret                                     // Return from main

swap:               
    stp x29, x30, [sp, -16]!                // Save FP (x29) and LR (x30), allocate stack space
    mov x29, sp                             // Set FP to SP     

    ldr temp_r, [x0]                        // Load value at *x into temp_r (temp = *x)
    ldr w10, [x1]                           // Load value at *y into w10 (w10 = *y)
    str w10, [x0]                           // Store y's value into x (*x = w10)
    str temp_r, [x1]                        // Store temp's value into y (*y = temp)

    ldp x29, x30, [sp], 16                  // Restore FP and LR, deallocate stack
    ret                                     // Return from swap
