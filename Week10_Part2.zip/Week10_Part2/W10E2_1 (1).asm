define(addf, `ldr x0, =str              // Load the format string address into x0
	mov w1, $1                      // Move first argument into w1
	mov w2, $2                      // Move second argument into w2
	add w3, w1, w2                  // Add w1 and w2, store result in w3
	bl printf')                     // Call printf to print the result

str: .string "%d + %d is %d\n"          // Define the format string for printf

	.balign 4                       // Align the code section on a 4-byte boundary
	.global main                    // Declare the main function as a global symbol

main:
	stp x29, x30, [sp, -16]!        // Save frame pointer (x29) and link register (x30) on stack
	mov x29, sp                     // Set frame pointer to the current stack pointer
	
	addf(1,2)                       // Call subroutine macro with arguments 1 and 2

	addf(3,4)                       // Call subroutine macro with arguments 3 and 4

	ldp x29, x30, [sp], 16          // Restore frame pointer (x29) and link register (x30) from stack
	ret                             // Return from main
