#include<stdio.h>
void addf(int a, int b) {
	printf("%d + %d is %d\n", a, b, a+b);
	
}

int main()
{
	addf(1,2);
	addf(3,4);
}
