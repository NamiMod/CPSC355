str_sp: .string "SP: %ld\n"       // Format string for printing SP

    .balign 4                     // Align the code section on a 4-byte boundary
    .global main                  // Declare main as a global symbol

func2:
    stp x29, x30, [sp, -16]!      // Save FP (x29) and LR (x30) on the stack and adjust SP
    mov x29, sp                   // Set FP to the current SP

    mov x1, sp                    // Move the stack pointer value into x1 for printing
    ldr x0, =str_sp               // Load the address of the format string into x0
    bl printf                     // Call printf to print SP

    ldp x29, x30, [sp], 16        // Restore FP (x29) and LR (x30) from the stack, adjust SP
    ret                           // Return to the caller

func1:
    stp x29, x30, [sp, -16]!      // Save FP (x29) and LR (x30) on the stack and adjust SP
    mov x29, sp                   // Set FP to the current SP

    mov x1, sp                    // Move the stack pointer value into x1 for printing
    ldr x0, =str_sp               // Load the address of the format string into x0
    bl printf                     // Call printf to print SP

    bl func2                      // Call func2

    ldp x29, x30, [sp], 16        // Restore FP (x29) and LR (x30) from the stack, adjust SP
    ret                           // Return to the caller

main:
    stp x29, x30, [sp, -16]!      // Save FP (x29) and LR (x30) on the stack and adjust SP
    mov x29, sp                   // Set FP to the current SP

    mov x1, sp                    // Move the stack pointer value into x1 for printing
    ldr x0, =str_sp               // Load the address of the format string into x0
    bl printf                     // Call printf to print SP

    bl func1                      // Call func1

    ldp x29, x30, [sp], 16        // Restore FP (x29) and LR (x30) from the stack, adjust SP
    ret                           // Return from main, terminating the program
