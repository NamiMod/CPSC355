










define(lvar_base_r, x9)                   
fmt1: .string "i: %ld, j: %ld\n"           // Format string for printf    

mystruct_i = 0                             // Offset for struct member i  
mystruct_j = 8                             // Offset for struct member j  

b_size = 16                                // Size of struct mystruct (16 bytes)  

alloc = -(16 + b_size) & -16               // Stack allocation size, aligned  
dealloc = -alloc                           // Deallocation size  

b_s = 16                                   // Offset of b in the stack  

.balign 4                                  // Align code on a 4-byte boundary  
.global main                               // Declare main as a global function  

main:                                      
    stp x29, x30, [sp, alloc]!             // Save FP (x29) and LR (x30), adjust stack  
    mov x29, sp                            // Set FP to current SP  

    add x8, x29, b_s                       // Calculate address of b in the stack  
    bl init                                // Call init function  
                                           // Result is stored in b  

    adrp x0, fmt1                          // Load page address of fmt1 into x0  
    add x0, x0, :lo12:fmt1                 // Get full address of fmt1  
    ldr x1, [x8, mystruct_i]               // Load b.i into x1  
    ldr x2, [x8, mystruct_j]               // Load b.j into x2  
    bl printf                              // Call printf to print values  

    mov w0, 0                              // Return 0 (exit code)  

    ldp x29, x30, [sp], dealloc            // Restore FP and LR, deallocate stack  
    ret                                    // Return from main  


lvar_size = 16                             // Size of lvar struct (16 bytes)  

alloc = -(16 + lvar_size) & -16            // Stack allocation size, aligned  
dealloc = -alloc                           // Deallocation size  

lvar_s = 16                                // Offset of lvar in the stack  

.balign 4                                  // Align code on a 4-byte boundary  

init:                                      
    stp x29, x30, [sp, alloc]!             // Save FP (x29) and LR (x30), adjust stack  
    mov x29, sp                            // Set FP to current SP  

    add lvar_base_r, x29, lvar_s           // Calculate base address of lvar struct  

    mov x12, 9                             // Set x12 to 9  
    str x12, [lvar_base_r, mystruct_i]     // Store 9 in lvar.i  
    str xzr, [lvar_base_r, mystruct_j]     // Store 0 in lvar.j (zero register xzr)  

    ldr x10, [lvar_base_r, mystruct_i]     // Load lvar.i into x10  
    str x10, [x8, mystruct_i]              // Store lvar.i into b.i  

    ldr x10, [lvar_base_r, mystruct_j]     // Load lvar.j into x10  
    str x10, [x8, mystruct_j]              // Store lvar.j into b.j  

    ldp x29, x30, [sp], dealloc            // Restore FP and LR, deallocate stack  
    ret                                    // Return from init  
