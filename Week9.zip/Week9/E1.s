fmt:  .string "index = %d, value = %d\n"
    .balign 4
    .global main

main:
    stp x29, x30, [sp, -48]!       // Set up the stack frame, save x29 (frame pointer) and x30 (link register)
    mov x29, sp

    // Create the array ia with values 1, 3, 6, 4, 5
    mov w19, 1                    // ia[0] = 1
    str w19, [x29, 16]
    mov w19, 3                    // ia[1] = 3
    str w19, [x29, 20]
    mov w19, 6                    // ia[2] = 6
    str w19, [x29, 24]
    mov w19, 4                    // ia[3] = 4
    str w19, [x29, 28]
    mov w19, 5                    // ia[4] = 5
    str w19, [x29, 32]

    // Loop through the array to find the number 4
    mov x21, 0                    // Index counter (x21)
loop:
    lsl x22, x21, #2              // Multiply x21 by 4 (to get the byte offset for 32-bit integers)
    add x22, x22, 16              // Add 16 to the offset (base address offset)
    ldr w19, [x29, x22]           // Load the current element into w19
    cmp w19, 4                    // Compare the current element with 4
    b.eq found                    // If equal, branch to found
    add x21, x21, 1               // Increment index
    cmp x21, 5                    // Check if we've reached the end of the array
    b.lt loop                     // If not, continue looping

    // If not found, skip to the end
    b end

found:
    ldr x0, =fmt                  // Load the address of the format string into x0
    mov w1, w21                   // Move the index where 4 was found into w1
    ldr w2, [x29, x22]            // Load the value of ia[index] into w2 (should be 4)
    bl printf                     // Call the printf function

end:
    ldp x29, x30, [sp], 48        // Restore x29 and x30, clean up the stack frame, and return
    ret

