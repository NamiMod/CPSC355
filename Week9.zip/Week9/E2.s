fmt:
    .string "%4d "                // Format string for printing each number.
newline:
    .string "\n"                  // Newline string.    
    
    .global main
    .balign 4
main:
    // Allocate 432 bytes: 432 = 400 (for our 10x10 table) + 16 (for FP and LR)
    stp     x29, x30, [sp, #-432]!    // Save FP and LR; adjust sp by 432 bytes.
    mov     x29, sp                   // Set frame pointer.
    
    sub     sp, sp, #400              // Allocate 400 bytes for our 10x10 array.
    // Now, the base address of our table is in sp.
    mov     x25, sp                   // x25 will be our base address for the table.

    // ---------------------------------------------------
    // Fill the multiplication table.
    // Outer loop: i from 1 to 10.
    mov     x19, #1                  // i = 1.
fill_outer_loop:
    cmp     x19, #11
    bge     fill_done

    // Inner loop: j from 1 to 10.
    mov     x20, #1                  // j = 1.
fill_inner_loop:
    cmp     x20, #11
    bge     fill_next_row

    // Compute product = i * j.
    mul     w21, w19, w20           // w21 = i * j.

    // Compute the 2D index: index = (i - 1) * 10 + (j - 1)
    sub     w22, w19, #1            // w22 = i - 1.
    sub     w23, w20, #1            // w23 = j - 1.
    mov     w24, #10                // constant 10.
    mul     w22, w22, w24           // w22 = (i - 1) * 10.
    add     w22, w22, w23           // w22 = (i - 1) * 10 + (j - 1).

    // Convert index to byte offset (each integer is 4 bytes).
    uxtw    x22, w22                // Zero-extend index to 64 bits.
    lsl     x22, x22, #2            // x22 = index * 4 (byte offset).

    // Compute the address for the element and store product.
    add     x23, x25, x22           // x23 = table base address + offset.
    str     w21, [x23]              // Store the product.

    add     x20, x20, #1            // j++.
    b       fill_inner_loop

fill_next_row:
    add     x19, x19, #1            // i++.
    b       fill_outer_loop

fill_done:
    // ---------------------------------------------------
    // Print the multiplication table.
    // Outer loop: iterate over rows (row index 0 to 9).
    mov     x19, #0                 // row = 0.
print_outer_loop:
    cmp     x19, #10
    bge     print_done

    // Inner loop: iterate over columns (col index 0 to 9).
    mov     x20, #0                 // col = 0.
print_inner_loop:
    cmp     x20, #10
    bge     print_newline

    // Compute the index = row * 10 + col.
    mov     x24, #10                // constant 10.
    mul     x22, x19, x24           // x22 = row * 10.
    add     x22, x22, x20           // x22 = row * 10 + col.
    lsl     x22, x22, #2            // Byte offset = index * 4.
    add     x23, x25, x22           // x23 = table base address + offset.
    ldr     w21, [x23]              // Load the product.

    // Print the value using the format string.
    ldr     x0, =fmt                // Load address of the format string.
    mov     w1, w21                 // Move product into w1.
    bl      printf

    add     x20, x20, #1            // col++.
    b       print_inner_loop

print_newline:
    ldr     x0, =newline            // Load newline string.
    bl      printf
    add     x19, x19, #1            // row++.
    b       print_outer_loop

print_done:
    // ---------------------------------------------------
    // Clean up: deallocate the 400-byte table space.
    add     sp, sp, #400            // Restore sp to the frame pointer level.
    ldp     x29, x30, [sp], #432     // Restore FP and LR, adjust sp back.
    ret
