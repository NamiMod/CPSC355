#include <stdio.h>
#include <stdlib.h>

// Define a struct to represent a student
typedef struct {
    char name[50];
    int age;
    int ID;
    float GPA;
} Student;

// Function to sort students by GPA in descending order
void sort_students_by_gpa(Student *students, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (students[j].GPA < students[j + 1].GPA) {
                // Swap students[j] and students[j + 1]
                Student temp = students[j];
                students[j] = students[j + 1];
                students[j + 1] = temp;
            }
        }
    }
}

int main() {
    int n;  // Number of students
    Student *students;  // Pointer for the student array

    // Prompt the user to enter the number of students
    printf("Enter the number of students: ");
    scanf("%d", &n);

    // Allocate memory for students
    students = (Student *)malloc(n * sizeof(Student));
    if (students == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Input details for each student
    for (int i = 0; i < n; i++) {
        printf("Enter details for student %d:\n", i + 1);
        printf("Name: ");
        scanf("%s", students[i].name);  // Read string with spaces
        printf("Age: ");
        scanf("%d", &students[i].age);
        printf("ID: ");
        scanf("%d", &students[i].ID);
        printf("GPA: ");
        scanf("%f", &students[i].GPA);
    }

    // Call the sort function to sort students by GPA
    sort_students_by_gpa(students, n);

    // Display the sorted list of students
    printf("\nSorted list of students by GPA (highest first):\n");
    for (int i = 0; i < n; i++) {
        printf("Name: %s, Age: %d, ID: %d, GPA: %.2f\n",
               students[i].name, students[i].age, students[i].ID, students[i].GPA);
    }

    // Free the allocated memory
    free(students);

    return 0;
}
