#include <stdio.h>
#include <stdlib.h>

// Function to calculate the total value of the array
int calculate_total(int *array, int size) {
    int total = 0;
    for (int i = 0; i < size; i++) {
        total += *(array + i);  // Use pointer arithmetic
    }
    return total;
}

int main() {
    int *inventory_values;  // Pointer for the array
    int n;                  // Number of items

    // Prompt user for the number of items
    printf("Enter the number of items in the warehouse: ");
    scanf("%d", &n);

    // Allocate memory for the array
    inventory_values = (int *)malloc(n * sizeof(int));
    if (inventory_values == NULL) {
        printf("Memory allocation failed.\n");
        return 1;
    }

    // Input the value of each item
    printf("Enter the value of each item:\n");
    for (int i = 0; i < n; i++) {
        printf("Item %d value: ", i + 1);
        scanf("%d", (inventory_values + i));
    }

    // Calculate the total value using the function
    int total_value = calculate_total(inventory_values, n);

    // Output the total value
    printf("The total value of the inventory is: %d\n", total_value);

    // Free the allocated memory
    free(inventory_values);

    return 0;
}
