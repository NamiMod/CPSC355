#include <stdio.h>
#include <stdlib.h>

// Function to calculate the total sum and count of temperatures
void calculate_average_and_count(FILE *input_file, float *average, int *count) {
    float temperature;
    float total_sum = 0.0;
    *count = 0;

    // Read temperatures from the file
    while (fscanf(input_file, "%f", &temperature) == 1) {
        total_sum += temperature;
        (*count)++;
    }

    // Calculate the average
    if (*count > 0) {
        *average = total_sum / (*count);
    } else {
        *average = 0.0;  // Handle case with no data
    }
}

int main() {
    FILE *input_file, *output_file;  // File pointers
    char input_file_name[] = "temperatures.txt";
    char output_file_name[] = "results.txt";

    float average;
    int count;

    // Open the input file for reading
    input_file = fopen(input_file_name, "r");
    if (input_file == NULL) {
        printf("Error: Could not open file %s for reading.\n", input_file_name);
        return 1;
    }

    // Calculate the average and count
    calculate_average_and_count(input_file, &average, &count);

    // Close the input file
    fclose(input_file);

    // Open the output file for writing
    output_file = fopen(output_file_name, "w");
    if (output_file == NULL) {
        printf("Error: Could not open file %s for writing.\n", output_file_name);
        return 1;
    }

    // Write the results to the output file
    fprintf(output_file, "Total number of entries: %d\n", count);
    fprintf(output_file, "Average temperature: %.2f°C\n", average);

    // Close the output file
    fclose(output_file);

    printf("Results have been written to %s.\n", output_file_name);

    return 0;
}
