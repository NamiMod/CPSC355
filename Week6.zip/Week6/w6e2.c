#include <stdio.h>

int main() {
    register unsigned int a = 0xC;   // 12 in hex (0xC)
    register unsigned int b = 0xA;   // 10 in hex (0xA)
    register unsigned int result;    // Register to store results

    // AND operation
    result = a & b;
    printf("result = 0x%08X\n", result);

    // OR inclusive operation
    result = a | b;
    printf("result = 0x%08X\n", result);

    // Exclusive OR (XOR)
    result = a ^ b;
    printf("result = 0x%08X\n", result);

    // AND NOT (a & ~b)
    result = a & (~b);
    printf("result = 0x%08X\n", result);

    // OR NOT (a | ~b)
    result = a | (~b);
    printf("result = 0x%08X\n", result);

    // Left Shift (LSL) by 2
    result = a << 2;
    printf("result = 0x%08X\n", result);

    // Right Shift (LSR) by 2
    result = b >> 2;
    printf("result = 0x%08X\n", result);

    // Move NOT
    result = ~a;
    printf("result = 0x%08X\n", result);

    return 0;
}
