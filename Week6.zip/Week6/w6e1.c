#include <stdio.h>

int main() {
    register int pos_num = 42;  // Positive number
    register int neg_num = -42; // Negative number

    printf("Positive Number: %d\n", pos_num);
    printf("Octal: %o\nHexadecimal: %X\n", pos_num, pos_num);

    printf("Negative Number: %d\n", neg_num);
    printf("Octal: %o\nHexadecimal: %X\n", neg_num, neg_num);

    return 0;
}
