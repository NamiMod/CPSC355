#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100 // Maximum size of the stack

// Global variables for the stack
int stack[MAX_SIZE];
int top = -1; // Top of the stack (-1 indicates an empty stack)

// Function to check if the stack is empty
int isEmpty() {
    return top == -1;
}

// Function to check if the stack is full
int isFull() {
    return top == MAX_SIZE - 1;
}

// Function to push an element onto the stack
void push(int value) {
    if (isFull()) {
        printf("Stack Overflow! Cannot push %d\n", value);
        return;
    }
    stack[++top] = value;
    printf("Pushed %d onto the stack\n", value);
}

// Function to pop an element from the stack
int pop() {
    if (isEmpty()) {
        printf("Stack Underflow! Cannot pop\n");
        return -1; // Return -1 to indicate error
    }
    return stack[top--];
}

// Function to peek at the top element of the stack
int peek() {
    if (isEmpty()) {
        printf("Stack is empty! Cannot peek\n");
        return -1; // Return -1 to indicate error
    }
    return stack[top];
}

// Function to display all elements in the stack
void display() {
    if (isEmpty()) {
        printf("Stack is empty! Nothing to display.\n");
        return;
    }
    printf("Stack elements (from top to bottom):\n");
    for (int i = top; i >= 0; i--) {
        printf("%d\n", stack[i]);
    }
}

// Main function to demonstrate stack operations
int main() {
    push(10);
    push(20);
    push(30);

    printf("Top element is %d\n", peek());

    printf("\nDisplaying stack contents:\n");
    display();

    printf("\nPopped %d from the stack\n", pop());
    printf("\nDisplaying stack contents after pop:\n");
    display();

    printf("\nPopped %d from the stack\n", pop());
    printf("\nPopped %d from the stack\n", pop());

    printf("\nDisplaying stack contents after all pops:\n");
    display();

    printf("\nStack is %sempty\n", isEmpty() ? "" : "not ");

    return 0;
}
