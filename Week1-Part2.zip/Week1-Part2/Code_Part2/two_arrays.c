#include <stdio.h>

void separateOddEven(int arr[], int size, int even[], int *evenCount, int odd[], int *oddCount) {
    *evenCount = 0; // Initialize even count
    *oddCount = 0;  // Initialize odd count

    for (int i = 0; i < size; i++) {
        if (arr[i] % 2 == 0) {
            even[(*evenCount)++] = arr[i]; // Add to even array
        } else {
            odd[(*oddCount)++] = arr[i];  // Add to odd array
        }
    }
}

int main() {
    int n;

    // Input the size of the array
    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    int arr[n], even[n], odd[n]; // Input, even, and odd arrays
    int evenCount, oddCount;    // Counts for even and odd arrays

    // Input the elements of the array
    printf("Enter %d integers:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // Separate odd and even numbers
    separateOddEven(arr, n, even, &evenCount, odd, &oddCount);

    // Print even numbers
    printf("Even numbers: ");
    for (int i = 0; i < evenCount; i++) {
        printf("%d ", even[i]);
    }
    printf("\n");

    // Print odd numbers
    printf("Odd numbers: ");
    for (int i = 0; i < oddCount; i++) {
        printf("%d ", odd[i]);
    }
    printf("\n");

    return 0;
}
