fmt_char:    .asciz "%c"

    .global main
    .balign 4
main:
    // Set up the stack frame (reserve 32 bytes)
    stp     x29, x30, [sp, -32]!
    mov     x29, sp

    mov     x20, sp          // x20 points to our string storage

    // Save "Hello" into memory, one character per byte.
    mov     w0, 72          // 'H'
    strb    w0, [x20, 16]
    mov     w0, #101         // 'e'
    strb    w0, [x20, 17]
    mov     w0, #108         // 'l'
    strb    w0, [x20, 18]
    mov     w0, #108         // 'l'
    strb    w0, [x20, 19]
    mov     w0, #111         // 'o'
    strb    w0, [x20, 20]
    mov     w0, #0           // Null terminator
    strb    w0, [x20, 21]

    // Set pointer for reading the string.
    add     x20, x20 , 16

print_loop:
    // Load one byte using post-indexing; x19 is incremented automatically.
    ldrb    w0, [x20], #1
    cmp     w0, #0           // Check for null terminator.
    b.eq     print_done

    // Save the character into w1 (printf's second argument for %c).
    mov     w1, w0

    // Load the address of the format string "%c" into x0.
    adrp    x0, fmt_char
    add     x0, x0, :lo12:fmt_char

    // Call printf to print one character.
    bl      printf

    b       print_loop      // Loop back to process the next character.

print_done:
    
    // Restore frame pointer and link register.
    ldp     x29, x30, [sp], #32
    ret


