fmt: .string "%d\n"

    .global main
    .balign 4
main:
    stp     x29, x30, [sp, -32]!    // Set up the stack frame; allocate 32 bytes.
    mov     x29, sp                 // Establish frame pointer.

    // -------------------------------
    // Expression 1: Compute 12*x + 30 for x = -12.
    // Expected: 12 * (-12) + 30 = -144 + 30 = -114.
    mov     w0, #-12                // w0 = x = -12.
    mov     w1, #12                 // w1 = 12.
    mul     w2, w0, w1              // w2 = 12 * (-12) = -144.
    add     w2, w2, #30             // w2 = -144 + 30 = -114.
    // Save result1 at offset 16 (relative to FP).
    str     w2, [x29, #16]

    // -------------------------------
    // Expression 2: Compute 10*x^2 + 2*x for x = -8.
    // Expected: 10 * (-8)^2 + 2 * (-8) = 10 * 64 - 16 = 640 - 16 = 624.
    mov     w3, #-8                // w3 = x = -8.
    mul     w4, w3, w3             // w4 = x^2 = 64.
    mov     w5, #10                
    mul     w4, w4, w5             // w4 = 64 * 10 = 640.
    mov     w5, #2
    mul     w5, w3, w5             // w5 = 2 * (-8) = -16.
    add     w4, w4, w5             // w4 = 640 + (-16) = 624.
    // Save result2 at offset 20 (relative to FP).
    str     w4, [x29, #20]

    // -------------------------------
    // Print both results.
    ldr     x0, =fmt               // Load address of the format string.
    ldr     w1, [x29, #16]         // Load result1 (-114).
    bl      printf

    ldr     x0, =fmt
    ldr     w1, [x29, #20]         // Load result2 (624).
    bl      printf

    // -------------------------------
    // Determine the maximum between result1 and result2.
    ldr     w2, [x29, #16]         // Load result1 into w2.
    ldr     w3, [x29, #20]         // Load result2 into w3.
    cmp     w2, w3
    bge     max_done               // If result1 >= result2, keep w2.
    mov     w2, w3                 // Else, move result2 (w3) into w2.
max_done:
    // Save the maximum value at offset 24.
    str     w2, [x29, #24]

    // Print the maximum value.
    ldr     x0, =fmt
    ldr     w1, [x29, #24]
    bl      printf

    // -------------------------------
    // Epilogue: restore FP and LR, and return.
    ldp     x29, x30, [sp], 32
    ret
