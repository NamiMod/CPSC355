// File: addf_float.s

.section .data
fmt: .asciz "%.1f + %.1f is %.1f\n"

.section .text
.global main

// void addf(float a, float b)
// Inputs: s0 = a, s1 = b
addf:
    stp x29, x30, [sp, -16]!
    mov x29, sp

    fadd s2, s0, s1        // s2 = a + b

    // Promote s0, s1, s2 to double for printf
    fcvt d0, s0            // a
    fcvt d1, s1            // b
    fcvt d2, s2            // result

    adrp x3, fmt
    add  x0, x3, :lo12:fmt
    bl printf

    ldp x29, x30, [sp], 16
    ret

// int main()
main:
    stp x29, x30, [sp, -16]!
    mov x29, sp

    // Call addf(1.5, 2.5)
    fmov s0, #1.5
    fmov s1, #2.5
    bl addf

    // Call addf(3.0, 4.0)
    fmov s0, #3.0
    fmov s1, #4.0
    bl addf

    ldp x29, x30, [sp], 16
    ret

