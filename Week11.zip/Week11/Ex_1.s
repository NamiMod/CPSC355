// File: midpoint.s

.section .data
pointA: .word 2, 6          // a = {2, 6}
pointB: .word 4, 10         // b = {4, 10}
result: .space 8            // struct Point result
fmt: .asciz "Midpoint: (%d, %d)\n"

.section .text
.balign 4 
.global main
midpoint:
    stp x29, x30, [sp, -16]!
    mov x29, sp

    // result->x = (a->x + b->x) / 2
    ldr w3, [x0]               // a->x
    ldr w4, [x1]               // b->x
    add w5, w3, w4
    asr w5, w5, #1
    str w5, [x2]

    // result->y = (a->y + b->y) / 2
    ldr w3, [x0, #4]           // a->y
    ldr w4, [x1, #4]           // b->y
    add w5, w3, w4
    asr w5, w5, #1
    str w5, [x2, #4]

    ldp x29, x30, [sp], 16
    ret
main:
    stp x29, x30, [sp, -16]!
    mov x29, sp

    adrp x0, pointA
    add  x0, x0, :lo12:pointA

    adrp x1, pointB
    add  x1, x1, :lo12:pointB

    adrp x2, result
    add  x2, x2, :lo12:result

    bl midpoint

    // Prepare for printf
    ldr w1, [x2]        // result->x
    ldr w2, [x2, #4]    // result->y

    adrp x3, fmt
    add  x0, x3, :lo12:fmt
    bl printf

    ldp x29, x30, [sp], 16
    ret

