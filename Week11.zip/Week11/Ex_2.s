// File: rectangle.s

// ----------------------------------------
// Data section: variables and format strings
.section .data
rect:   .space 20                  // Allocate 20 bytes for struct Rectangle
fmt:    .asciz "Area = %d\n"       // Format string for printf

// ----------------------------------------
// Code section
.section .text
.global main
// ----------------------------------------
setRectangle:
    stp x29, x30, [sp, -16]!       // Save frame pointer and link register
    mov x29, sp                    // Set up new frame pointer

    str w1, [x0]                   // r->x      = x
    str w2, [x0, #4]               // r->y      = y
    str w3, [x0, #8]               // r->width  = w
    str w4, [x0, #12]              // r->height = h

    mul w5, w3, w4                 // w5 = width * height
    str w5, [x0, #16]              // r->area   = w5

    ldp x29, x30, [sp], 16         // Restore frame pointer and link register
    ret

main:
    stp x29, x30, [sp, -16]!       // Save frame pointer and link register
    mov x29, sp                    // Set up new frame pointer

    // Load address of rect into x0 (1st argument to setRectangle)
    adrp x0, rect
    add  x0, x0, :lo12:rect

    // Load arguments for setRectangle
    mov w1, #5                     // x = 5
    mov w2, #10                    // y = 10
    mov w3, #8                     // width = 8
    mov w4, #6                     // height = 6

    bl setRectangle                // Call subroutine to fill the struct

    // Load area (offset 16) and print it
    ldr w1, [x0, #16]              // w1 = r->area

    // Prepare format string in x0
    adrp x2, fmt
    add  x0, x2, :lo12:fmt

    bl printf                      // printf("Area = %d\n", area)

    mov w0, #0                     // return 0;
    ldp x29, x30, [sp], 16         // Restore frame and return
    ret

