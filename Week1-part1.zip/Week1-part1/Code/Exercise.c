#include <stdio.h>

// Function declarations
void calculateAverage(int grades[], int n, float *average);
void findMinMax(int grades[], int n, int *min, int *max);


int main() {
    int n, i, minGrade, maxGrade;
    float average;
    int grades[10]; // Fixed-size array

    // Input the number of students
    do {
        printf("Enter the number of students (1-%d): ", 10);
        scanf("%d", &n);
        if (n < 1 || n > 10) {
            printf("Invalid number of students. Please enter a value between 1 and %d.\n", 10);
        }
    } while (n < 1 || n > 10);

    // Input grades for each student
    printf("Enter the grades (0-100):\n");
    for (i = 0; i < n; i++) {
        do {
            printf("Grade for student %d: ", i + 1);
            scanf("%d", &grades[i]);
            if (grades[i] < 0 || grades[i] > 100) {
                printf("Invalid grade! Please enter a value between 0 and 100.\n");
            }
        } while (grades[i] < 0 || grades[i] > 100);
    }

    // Calculate the average grade
    calculateAverage(grades, n, &average);

    // Find the minimum and maximum grades
    findMinMax(grades, n, &minGrade, &maxGrade);

    // Output the results
    printf("\nResults:\n");
    printf("Average grade: %.2f\n", average);
    printf("Highest grade: %d\n", maxGrade);
    printf("Lowest grade: %d\n", minGrade);

    return 0;
}

// Function to calculate the average grade
void calculateAverage(int grades[], int n, float *average) {
    int sum = 0;
    for (int i = 0; i < n; i++) {
        sum += grades[i];
    }
    *average = (float)sum / n; // Using call by reference to store result
}

// Function to find the minimum and maximum grades
void findMinMax(int grades[], int n, int *min, int *max) {
    *min = grades[0];
    *max = grades[0];
    for (int i = 1; i < n; i++) {
        if (grades[i] < *min) {
            *min = grades[i];
        }
        if (grades[i] > *max) {
            *max = grades[i];
        }
    }
}
