#include <stdio.h>

// Call by value function
void callByValue(int a) {
    a = 20; // Change the value of a
    printf("Inside callByValue: a = %d\n", a);
}

// Call by reference function
void callByReference(int *b) {
    *b = 20; // Change the value at the memory address of b
    printf("Inside callByReference: b = %d\n", *b);
}

int main() {
    int x = 10, y = 10;

    printf("Before callByValue: x = %d\n", x);
    callByValue(x); // Passing value of x
    printf("After callByValue: x = %d\n", x); // x remains unchanged

    printf("\nBefore callByReference: y = %d\n", y);
    callByReference(&y); // Passing address of y
    printf("After callByReference: y = %d\n", y); // y is changed

    return 0;
}


