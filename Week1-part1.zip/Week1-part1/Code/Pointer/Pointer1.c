#include <stdio.h>
#include <string.h>
 
int main(){
    
    int number = 10;
    printf("%p", &number);
    
    return 0;
}