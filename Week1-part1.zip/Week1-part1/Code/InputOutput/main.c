#include <stdio.h>

int main() {
    
    char str[100];
    int number;
    char second_str[100];
    int second_number;


    printf("Enter a String: ");
    scanf("%s", str);

    printf("Enter a Number: ");
    scanf("%d", &number);

    printf("Enter a String and a Number: ");
    scanf("%s %d", second_str, &second_number);

    printf("------\n");

    printf("You entered: %s\nYou entered %d\n", str, number);
    printf("You entered: %s\nYou entered %d\n", second_str, second_number);
    
    return 0;
}


