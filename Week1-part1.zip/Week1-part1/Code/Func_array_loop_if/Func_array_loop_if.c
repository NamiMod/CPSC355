#include <stdio.h>

// Function to print even numbers in an array
void printEvenNumbers(int arr[], int size) {
    printf("Even numbers in the array are:\n");
    
    // Loop through each element in the array
    for (int i = 0; i < size; i++) {
        // Check if the current element is even
        if (arr[i] % 2 == 0) {
            printf("%d ", arr[i]); // Print the even number
        }
    }
    
    printf("\n"); // Newline for better formatting
}

int main() {
    int numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // Example array
    int size = sizeof(numbers) / sizeof(numbers[0]); // Calculate array size
    
    printEvenNumbers(numbers, size); // Call the function
    
    return 0;
}




