STUDENT_NUMBER = 0   // offset of 'number' in struct student
STUDENT_GRADE = 4   // offset of 'grade' in struct student
STUDENT_SIZE  = 8   // total struct size = 8 bytes (4 + 4)

TOTAL_SIZE = 16

S1_OFFSET = 16
S2_OFFSET = 24

fmt:    .asciz "Average grade: %d\n"

        .balign 4
        .global main

main:
        
        stp     x29, x30, [sp, -32]!
        mov     x29, sp

        add     x19, x29, S1_OFFSET
        add     x20, x29, S2_OFFSET

        mov     w0, #1111
        str     w0, [x19, STUDENT_NUMBER]

        mov     w0, #85
        str     w0, [x19, STUDENT_GRADE]

        mov     w0, #2222
        str     w0, [x20, STUDENT_NUMBER]

        mov     w0, #90
        str     w0, [x20, STUDENT_GRADE]

        ldr     w0, [x19, STUDENT_GRADE]  // w0 = s1.grade
        ldr     w1, [x20, STUDENT_GRADE]  // w1 = s2.grade
        add     w2, w0, w1                 // w2 = w0 + w1
        lsr     w2, w2, #1                 // w2 = w2 >> 1 (divide by 2)

        adrp    x0, fmt
        add     x0, x0, :lo12:fmt   
        mov     w1, w2              
        bl      printf

        ldp     x29, x30, [sp], 32
        ret
