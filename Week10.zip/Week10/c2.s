STUDENT_NUMBER = 0    // offset of 'number' in struct student
STUDENT_GRADE  = 4    // offset of 'grade' in struct student
STUDENT_SIZE   = 8    // total struct size (4 + 4)

NUM_STUDENTS   = 5    // total number of students


S1_OFFSET = 16       
S2_OFFSET = 24       
S3_OFFSET = 32       
S4_OFFSET = 40       
S5_OFFSET = 48       

fmt:    .asciz "Average grade: %d\n"

        .balign 4
        .global main

main:
        
        stp     x29, x30, [sp, -96]!
        mov     x29, sp

        // Student 1 (at offset S1_OFFSET)
        add     x19, x29, S1_OFFSET
        mov     w0, #1111
        str     w0, [x19, #STUDENT_NUMBER]
        mov     w0, #85
        str     w0, [x19, #STUDENT_GRADE]

        // Student 2 (at offset S2_OFFSET)
        add     x19, x29, S2_OFFSET
        mov     w0, #2222
        str     w0, [x19, #STUDENT_NUMBER]
        mov     w0, #90
        str     w0, [x19, #STUDENT_GRADE]

        // Student 3 (at offset S3_OFFSET)
        add     x19, x29, S3_OFFSET
        mov     w0, #3333
        str     w0, [x19, #STUDENT_NUMBER]
        mov     w0, #75
        str     w0, [x19, #STUDENT_GRADE]

        // Student 4 (at offset S4_OFFSET)
        add     x19, x29, S4_OFFSET
        mov     w0, #4444
        str     w0, [x19, #STUDENT_NUMBER]
        mov     w0, #80
        str     w0, [x19, #STUDENT_GRADE]

        // Student 5 (at offset S5_OFFSET)
        add     x19, x29, S5_OFFSET
        mov     w0, #5555
        str     w0, [x19, #STUDENT_NUMBER]
        mov     w0, #95
        str     w0, [x19, #STUDENT_GRADE]

        // ----- Loop over the array to sum grades -----
        
        mov     w2, #0          // sum accumulator
        mov     w3, #0          // loop index
        // Set pointer x4 to the beginning of the array (Student 1)
        add     x4, x29, S1_OFFSET

loop:
        cmp     w3, #NUM_STUDENTS   // check if we've processed 5 students
        bge     done_loop           // if index >= 5, exit loop

        ldr     w5, [x4, #STUDENT_GRADE]  // load current student's grade
        add     w2, w2, w5                // add grade to sum
        add     x4, x4, #STUDENT_SIZE     // move pointer to next student
        add     w3, w3, #1                // increment loop counter
        b       loop

done_loop:
        
        mov     w6, #5              
        udiv    w2, w2, w6          

        
        adrp    x0, fmt
        add     x0, x0, :lo12:fmt   
        mov     w1, w2              
        bl      printf

        
        ldp     x29, x30, [sp], 96
        ret
