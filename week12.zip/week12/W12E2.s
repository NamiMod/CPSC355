.text

spring_l:   .string "spring"                    // String for "spring"
summer_l:   .string "summer"                    // String for "summer"
fall_l:     .string "fall"                      // String for "fall"
winter_l:   .string "winter"                    // String for "winter"

fmt:        .string "season[%d] = %s\n"         // Print format string

.data
.balign 8
season_m:   .dword spring_l, summer_l, fall_l, winter_l   // Array of season strings

.text
.balign 4
.global main

main:
	stp x29, x30, [sp, -16]!             // Save x29 and x30
	mov x29, sp                          // Set frame pointer

	mov w19, 0                           // i = 0
	b pretest                            // Jump to loop test

looptop:
	ldr x0, =fmt                         // Load format string
	mov w1, w19                          // Load index as int
	ldr x20, =season_m                   // Load base address of season_m
	ldr x2, [x20, w19, SXTW 3]           // Load season[i]
	bl printf                            // Call printf

	add w19, w19, 1                      // i++

pretest:
	cmp w19, 4                           // Compare i < 4
	b.lt looptop                         // Loop if true

	ldp x29, x30, [sp], 16               // Restore x29 and x30
	ret                                  // Return
