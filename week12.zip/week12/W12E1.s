.text
fmt:        .string "%s\n"                          // Format string for printf

.balign 4
.global main

/*
	int argc = w0
	char * argv = x1
*/
main:
	stp x29, x30, [sp, -16]!                         // Save frame pointer and return address
	mov x29, sp                                      // Set up new frame pointer

	mov w20, w0                                      // Copy argc to w20
	mov x21, x1                                      // Copy argv to x21

	mov w19, 0                                       // i = 0
	b pretest                                        // Jump to test condition

looptop:
	ldr x0, =fmt                                     // Load format string
	ldr x1, [x21, w19, SXTW 3]                       // Load argv[i]
	bl printf                                        // Call printf

	add w19, w19, 1                                  // i++

pretest:
	cmp w19, w20                                     // Compare i with argc
	b.lt looptop                                     // If i < argc, loop

	ldp x29, x30, [sp], 16                           // Restore frame and return
	ret                                              // Return from main
