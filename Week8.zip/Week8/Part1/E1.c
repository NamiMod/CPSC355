#include <stdio.h>

int main()
{
	int a = 7;
	int b = 2;

	if (b <= a) {		
		int c = a - b;
		printf("c is %d", c);
	}
	return 0;
}
