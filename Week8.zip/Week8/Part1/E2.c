#include <stdio.h>

int main()
{
	int a = 10;
	int b = 5;

	int c = a - b;

	if (c > 0){
		a = a + 1;
		b = b - 1;
		c = a * b;
		printf("c is %d", c);
	} else {
		a = a + 2;
		b = b - 2;
		c = a * b;
		printf("c is %d", c);
	}
	return 0;
}

